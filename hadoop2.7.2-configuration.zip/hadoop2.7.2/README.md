Hadoop 2.7.1 on windows This is a reference repository for below tutorial

This is a simple tutorial which will guide you how to install latest hadoop 2.7.1 on windows in less than 10 mints without cygwin in a very simple way

http://toodey.com/2015/08/10/hadoop-installation-on-windows-without-cygwin-in-10-mints/


This repository contains 'conf' directory and 'bin' directory for hadoop 2.7.1 bin directory with winutils.exe, hdfs.exe, hdfs.dll, hadoop.exe,hadoop.dll and etc.
